import numpy as np
import threading
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot
import logging
from freq_utils import SweepConfig

logger = logging.getLogger("Processor")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
formatter = logging.Formatter("[%(name)s] %(message)s")
ch.setFormatter(formatter)
logger.addHandler(ch)


def rcosdesign(beta, span, sps):
    N = span * sps
    t = np.arange(-N / 2, N / 2 + 1) / sps
    h = np.sinc(t) * np.cos(np.pi * beta * t) / (1 - (2 * beta * t)**2)
    h[t == 0.0] = 1.0
    h[np.abs(2 * beta * t) == 1] = np.pi / 4
    h = h / np.sum(h)
    return h


class SignalProcessor(QObject):
    signal_fft_ready = pyqtSignal(np.ndarray, np.ndarray)
    signal_sweep_ready = pyqtSignal(np.ndarray, np.ndarray)
    signal_constellation_ready = pyqtSignal(np.ndarray)
    signal_iq_ready = pyqtSignal(np.ndarray, np.ndarray)

    def __init__(self, sweep_config: SweepConfig, parent=None):
        super().__init__(parent)
        self.sweep_config = sweep_config
        self._sweep_config_version = sweep_config.version()
        self._rrc_filter = rcosdesign(beta=0.35, span=8, sps=8)
        self._reset_sweep_buffers()
        self.running = False
        self.thread = None

    def _reset_sweep_buffers(self):
        self.sweep_mags = []
        self.current_step = 0
        logger.debug("Sweep buffers reset.")

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._process_loop, daemon=True)
        self.thread.start()

    @pyqtSlot(float, float, bytes)
    def process_frame(self, sample_freq: float, lo_freq_hz: float, frame_bytes: bytes):
        # 检查配置是否变化
        if self.sweep_config.version() != self._sweep_config_version:
            logger.debug("Sweep config changed externally, resetting sweep state.")
            self._sweep_config_version = self.sweep_config.version()
            self._reset_sweep_buffers()

        if self.current_step >= self.sweep_config.points:
            logger.debug("Sweep limit reached. Dropping current frame and resetting sweep.")
            self._reset_sweep_buffers()
            return

        try:
            complex_iq = self._decode_iq_from_bytes(frame_bytes)
        except Exception as e:
            logger.warning(f"IQ decode failed: {e}")
            return

        self.signal_constellation_ready.emit(complex_iq)
        self.signal_iq_ready.emit(complex_iq.real, complex_iq.imag)

        fft_result = np.fft.fftshift(np.fft.fft(complex_iq))
        magnitude = 20 * np.log10(np.abs(fft_result) + 1e-6)
        freqs = np.linspace(-sample_freq / 2, sample_freq / 2, len(magnitude)) + lo_freq_hz
        self.signal_fft_ready.emit(freqs, magnitude)

        self._update_sweep(complex_iq)

        logger.debug(f"Processed frame: LO = {lo_freq_hz / 1e6:.2f} MHz, "
                     f"Sample Freq = {sample_freq / 1e6:.2f} MHz, "
                     f"Current Step = {self.current_step}, Sweep Points = {self.sweep_config.points}")

    def _update_sweep(self, iq: np.ndarray):
        rx_up = np.zeros(len(iq) * 2, dtype=np.complex64)
        rx_up[::2] = iq
        rx_interp = np.convolve(rx_up, self._rrc_filter, mode='same')

        fft_len = int(2 ** np.ceil(np.log2(len(rx_interp))))
        rx_fft = np.fft.fftshift(np.fft.fft(rx_interp, fft_len))
        mag = 20 * np.log10(np.abs(rx_fft) + 1e-6)

        center = fft_len // 2
        side_len = fft_len // 8
        side_mag = mag[center - side_len:center + side_len]
        side_mag = np.delete(side_mag, side_len)

        self.sweep_mags.append(side_mag.copy())
        self.current_step += 1

        spectrum_combined = np.concatenate(self.sweep_mags)
        freq_axis = np.linspace(self.sweep_config.start, self.sweep_config.stop, len(spectrum_combined))
        self.signal_sweep_ready.emit(freq_axis, spectrum_combined)

    def _decode_iq_from_bytes(self, data_bytes: bytes) -> np.ndarray:
        data = np.frombuffer(data_bytes, dtype=np.uint8)
        if len(data) % 4 != 0:
            raise ValueError("数据长度必须是 4 的倍数")

        data = data.reshape(-1, 4)

        def decode_pairs(byte_pair: np.ndarray) -> np.ndarray:
            b0 = byte_pair[:, 0].astype(np.uint8)
            b1 = byte_pair[:, 1].astype(np.uint8)

            n0 = ((b0 & 0xF0) >> 4).astype(np.int32)
            n1 = (b0 & 0x0F).astype(np.int32)
            n2 = ((b1 & 0xF0) >> 4).astype(np.int32)
            n3 = (b1 & 0x0F).astype(np.int32)

            val = n0 * 256 + n1 * 4096 + n2 * 1 + n3 * 16
            val[val >= 32768] -= 65536
            return val.astype(np.float32)

        I = decode_pairs(data[:, 0:2])
        Q = decode_pairs(data[:, 2:4])
        return I + 1j * Q

    def _process_loop(self):
        while self.running:
            pass
